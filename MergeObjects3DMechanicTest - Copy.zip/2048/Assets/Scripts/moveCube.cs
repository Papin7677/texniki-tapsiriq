using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCube : MonoBehaviour
{

    public float force = 100f; 
    private Camera cam;
    private Collider planeCollider;
    RaycastHit hit;
    Ray ray;
    bool isNew = true; //this is required so that the script does not move the same cube twice or more
    
    void Start()
    {
         planeCollider = GameObject.Find("Wall2049").GetComponent<MeshCollider>();
        cam =  Camera.main;
    }
    
    void FixedUpdate()
    {//calculates the vector and applies it as a relative force to the cube 
        ray = cam.ScreenPointToRay(Input.mousePosition); 

        if (isNew&&Input.GetMouseButton(0) && Physics.Raycast(ray, out hit))
        {
            
            if (hit.collider == planeCollider|| hit.collider.gameObject.layer == 6)
            {
                GetComponent<Rigidbody>().isKinematic = false;
                GetComponent<Rigidbody>().AddRelativeForce(hit.point*force);
                isNew = false;
                createCube.doCreate = true;

            }
        }
    }
    
    
}

