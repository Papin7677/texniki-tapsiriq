using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// this code is generating the cubes ranging from 2 till 8
public class createCube : MonoBehaviour
{
    public Vector3 firstPos;// position of the spawn
    public GameObject prefab2, prefab4, prefab8;
    public static bool doCreate = false;//this will be set to true by moveCube.cs script when the generated cub is moved. this will activated the setDoCreatePriv() mehtod which will set doCreatePriv to true and will run the code for generation of the cubes
    private static bool doCreatePriv = true;

    // Update is called once per frame
    void Update()
    {
        joinCubes.once = 1; //sets once paramenter in joinCubes to 1
        
        if(doCreatePriv)
        {
            
            //generated a random number from 1 to 9 and depending on the number generated it will create a cube on the firstPos and will set its isKinematic to true
                int randomNumb = Random.Range(1, 9);
                if (randomNumb < 4)
                {
                    GameObject obj = Instantiate(prefab2, firstPos, Quaternion.identity);
                    
                    obj.GetComponent<Rigidbody>().isKinematic = true;


                }
                else if(randomNumb >4 && randomNumb<7)
                {
                    GameObject obj = Instantiate(prefab4, firstPos, Quaternion.identity);
                   
                    obj.GetComponent<Rigidbody>().isKinematic = true;

                }
                else
                {
                    GameObject obj = Instantiate(prefab8, firstPos, Quaternion.identity);
                  
                    obj.GetComponent<Rigidbody>().isKinematic = true;


            }
                doCreatePriv = false;//makes sure that the cubes are not generated while there is still a cube in firstPos
                
            
            
        }
        if (doCreate)
        {
            Invoke("setDoCreatePriv", 1);
        }
        doCreate = false;

    }
    private void setDoCreatePriv()
    {
        doCreatePriv = true;
    }
}
