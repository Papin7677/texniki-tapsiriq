using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//This code is responsible for the combination of cubes.
public class joinCubes : MonoBehaviour
{
    public GameObject pref2, pref4, pref8, pref16, pref32, pref64, pref128, pref256, pref512,pref1024, pref2048; //save the prefabs of all cubes
    public static int once = 1; //this makes sure that only one cube is made from 2 smaller ones ##2+2=4, 4+4=8 and not 2+2=4+4 
    private void OnTriggerEnter(Collider secondCube)// whenever there is a collision this method will be called and the collided object will be set to secondCube
    {
        if(transform.tag == secondCube.tag)//checks wheter the collided cubes are same
        {
            GameObject obj;
            if (tag == "2" && once == 1) //if the collided cubes are 2
            {
                obj = Instantiate(pref4, transform.position, Quaternion.identity); //create a combination of two cubes.
                once = 0; //this is set to zero so that the collided cube (secondCube) does not create a second combined cube 
                Destroy(transform.gameObject);//destroys the combined cubes
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up*100); //makes the new cube jump a bit
                
            }

            if (tag == "4" && once == 1) //if the collided cubes are 4
            {
                obj = Instantiate(pref8, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }

            if (tag == "8" && once == 1)
            {
                obj = Instantiate(pref16, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }

            if (tag == "16" && once == 1)
            {
                obj = Instantiate(pref32, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }
            if (tag == "32" && once == 1)
            {
                obj = Instantiate(pref64, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }
            if (tag == "64" && once == 1)
            {
                obj = Instantiate(pref128, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }
            if (tag == "128" && once == 1)
            {
                obj = Instantiate(pref256, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }
            if (tag == "256" && once == 1)
            {
                obj = Instantiate(pref512, transform.position, Quaternion.identity);
                once = 0;
                Destroy(transform.gameObject);
                Destroy(secondCube.gameObject);
                obj.GetComponent<Rigidbody>().AddRelativeForce(Vector3.up * 100);
                
            }

            

            

        }
    }
}
